<?php

namespace BatBook;

use BatBook\Exempcions\InvalidFormatException;

class Course
{
    private $id;
    private $cycle;

    private $idFamily;

    private $vliteral;

    private $cliteral;

    public static string $nameTable = 'courses';

    public function __construct($cycle='', $idFamily='', $vliteral='', $cliteral='')
    {
        $this->cycle = $cycle;
        $this->idFamily = $idFamily;
        $this->vliteral = $vliteral;
        $this->cliteral = $cliteral;
    }

    // Setters
    public function setCycle($cycle)
    {
        $this->cycle = $cycle;
    }

    public function setIdFamily($idFamily)
    {
        $this->idFamily = $idFamily;
    }

    public function setVliteral($vliteral)
    {
        $this->vliteral = $vliteral;
    }

    public function setCliteral($cliteral)
    {
        $this->cliteral = $cliteral;
    }

    // Getters
    public function getCycle()
    {
        return $this->cycle;
    }

    public function getIdFamily()
    {
        return $this->idFamily;
    }

    public function getVliteral()
    {
        return $this->vliteral;
    }

    public function getCliteral()
    {
        return $this->cliteral;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id): void
    {
        $this->id = $id;
    }

    // __toString Method
    public function __toString()
    {
        return "<div clas='course'>
                    <h3>Cycle: $this->cycle</h3>
                    <h5>ID Family: $this->idFamily</h5>
                    <h6>Vliteral: $this->vliteral</h6>
                    <h6>Cliteral: $this->cliteral</h6>
                </div>";
    }

    // __toJson Method
    public function toJson()
    {
        return json_encode(get_object_vars($this));
    }

    public static function find($id)
    {
        return QueryBuilder::find(Course::class, $id);
    }

    public function delete(){
        return QueryBuilder::delete(Course::class, $this->id);
    }



}
