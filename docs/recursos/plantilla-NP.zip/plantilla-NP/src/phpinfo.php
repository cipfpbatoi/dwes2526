<?php
    phpinfo();
?>